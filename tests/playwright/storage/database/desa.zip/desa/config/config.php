<?php
// ----------------------------------------------------------------------------
// Konfigurasi aplikasi dalam berkas ini merupakan setting konfigurasi tambahan
// SID. Letakkan setting konfigurasi ini di desa/config/config.php.
// ----------------------------------------------------------------------------

// Uncomment jika situs ini untuk demo. Pada demo, user admin tidak bisa dihapus
// dan username/password tidak bisa diubah

$config['demo_mode'] = true;

// Setting ini untuk menentukan user yang dipercaya. User dengan id di setting ini
// dapat membuat artikel berisi video yang aktif ditampilkan di Web.
// Misalnya, ganti dengan id = 1 jika ingin membuat pengguna admin sebagai pengguna terpecaya.
$config['user_admin'] = 0;

// Untuk menghindari masalah keamanan, Anda mungkin ingin mengonfigurasi daftar "host tepercaya".
// Contoh: ['localhost', 'my-development.com', 'my-production.com', 'subdomain.domain.com']
$config['trusted_hosts'] = [];

$config['server_layanan'] = 'http://opensid-layanan.test';
// $config['server_layanan'] = 'http://devlayanan.opendesa.id';
$config['token_layanan']  = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL3d3dy5kZXZsYXlhbmFuLm9wZW5kZXNhLmlkL3BlbWVzYW5hbi84NTEwIiwiaWF0IjoxNzQxNjYwNTA4LCJleHAiOjE3Njc0MDc3MDgsIm5iZiI6MTc0MTY2MDUwOCwianRpIjoiTGVFenJiOHNjWFBzRmlqVCIsInN1YiI6IjE5NzgiLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3IiwiZGVzYV9pZCI6IjE1LjA1LjAyLjIwMTYiLCJrZWNhbWF0YW5faWQiOiIiLCJkb21haW4iOiJodHRwczovL3R1bmFzbXVkby5iZXJkZXNhLmlkIiwidGFuZ2dhbF9iZXJsYW5nZ2FuYW4iOnsibXVsYWkiOiIyMDIyLTA5LTI4IiwiYWtoaXIiOiIyMDI2LTAxLTMxIiwiYW1iaWx2IjoiMjUwMyIsImFtYmlscCI6IjI2MDEiLCJhbWJpbGQiOiIyNTAzIiwidmVyc2lfbGF5YW5hbiI6IjI1MDMuMC4xLXByZW1pdW0iLCJhbmp1bmdhbiI6IiIsImxpY2Vuc2VfYW5qdW5nYW4iOmZhbHNlLCJuYW1hX25wd3AiOiJEZXNhIFR1bmFzIE11ZG8gS2VjYW1hdGFuIFNha2VybmFuIEthYnVwYXRlbiBNdWFybyBKYW1iaSIsIm5vX25wd3AiOiIwMDExMTE1MzMzMzEwMDAifX0.qZIVZ6c2lpnm2tolZVDrAVoZSfu-YttCczBe41nAK1s';

$config['sess_save_path'] = 'storage/framework/sessions';
